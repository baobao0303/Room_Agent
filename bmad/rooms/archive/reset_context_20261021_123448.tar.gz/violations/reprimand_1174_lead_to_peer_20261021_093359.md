# BIÊN BẢN KHIỂN TRÁCH & XỬ PHẠT QUY TẮC SLPC (AGENT SANCTION MEMO)

- **Thời gian**: `2026-10-21 09:33:59`
- **Work Item liên quan**: `#1174`
- **Agent khiển trách (From)**: `Lead`
- **Agent vi phạm (Target)**: `Peer`
- **Hành vi vi phạm**: **[DEAD_CODE] Để lại import rác, ViewChild mồ côi hoặc code thừa sau refactor**

---

## 1. NỘI DUNG PHÊ BÌNH & CẢNH CÁO (REPRIMAND MESSAGE)
> "Refactor sang tds-table nhưng không dọn dẹp import và ViewChild thừa, vi phạm nguyên tắc Lazy Senior Dev và làm bẩn codebase!"

---

## 2. BẰNG CHỨNG THỰC NGHIỆM KHÁCH QUAN (EMPIRICAL EVIDENCE)
```text
apps/mfe-cdp/.../raw-event-list.component.ts: import TDSDataTableModule and @ViewChild dataTableComponent unused after tds-table migration
```

---

## 3. CHỈ THỊ KHẮC PHỤC BẮT BUỘC (CORRECTIVE ACTION MANDATE)
- Agent `Peer` phải lập tức khắc phục lỗi trên, xóa sạch code vi phạm và tự kiểm thử lại.
- Tuyệt đối không được chuyển trạng thái Task sang bước kế tiếp khi lỗi chưa được giải quyết dứt điểm.
