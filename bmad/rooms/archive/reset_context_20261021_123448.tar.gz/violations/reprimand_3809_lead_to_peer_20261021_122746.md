# BIÊN BẢN KHIỂN TRÁCH & XỬ PHẠT QUY TẮC SLPC (AGENT SANCTION MEMO)

- **Thời gian**: `2026-10-21 12:27:46`
- **Work Item liên quan**: `#3809`
- **Agent khiển trách (From)**: `Lead`
- **Agent vi phạm (Target)**: `Peer`
- **Hành vi vi phạm**: **[HARDCODED_HEX] Dùng mã màu hex cứng (#...) thay vì TDS Design Tokens**

---

## 1. NỘI DUNG PHÊ BÌNH & CẢNH CÁO (REPRIMAND MESSAGE)
> "Code không đạt tiêu chuẩn kiến trúc Lead Review! Bắt buộc sửa lại."

---

## 2. BẰNG CHỨNG THỰC NGHIỆM KHÁCH QUAN (EMPIRICAL EVIDENCE)
```text
{
  "total_findings": 1,
  "findings": [
    {
      "file": "apps/mfe-cdp/src/app/pages/data-raw/raw-event-list.component.html",
      "severity": "WARN",
      "category": "TDS_DESIGN_TOKEN",
      "detail": "Phát hiện mã màu hex cứng: `+`. Khuyến nghị thay thế bằng TDS token (e.g. `tds-color-text-primary`, `tds-color-primary-500-light`)."
    }
  ],
  "verdict": "ADVICE_PROVIDED"
}

```

---

## 3. CHỈ THỊ KHẮC PHỤC BẮT BUỘC (CORRECTIVE ACTION MANDATE)
- Agent `Peer` phải lập tức khắc phục lỗi trên, xóa sạch code vi phạm và tự kiểm thử lại.
- Tuyệt đối không được chuyển trạng thái Task sang bước kế tiếp khi lỗi chưa được giải quyết dứt điểm.
